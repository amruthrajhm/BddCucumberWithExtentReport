package enums;

public enum LocatorType {
XPATH,
ID,
NAME,
CLASSNAME,
TAGNAME,
CSS
}
