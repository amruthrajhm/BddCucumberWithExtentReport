package enums;

public enum ActionType {
	CLICK,
	SELECT,
	SETTEXT,
	GETTEXT

}
